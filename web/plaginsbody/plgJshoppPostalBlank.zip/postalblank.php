<?php
class JshoppingControllerPostalBlank extends JControllerLegacy {
    function __construct( $config = array() )
    {
        parent::__construct( $config );
        $this->registerTask('add', 'edit' );
        checkAccessController("postalblank");
        addSubmenu("postalblank");
    }
    public function display()
    {
        $plagin = &JPluginHelper::getPlugin('system','JshoppPostalBlank');
        $plaginParams = json_decode($plagin->params);
        $order = JSFactory::getTable('order', 'jshop');
        $order_id = $this->input->getInt("order_id");
        $db = JFactory::getDbo();
        $q = "SELECT * FROM `#__jshopping_orders` WHERE `order_id` = $order_id";
        $db->setQuery($q);
        $orderdb = $db->loadObject();
        $vendorinfo = $order->getVendorInfo();
        $ch = curl_init();
        $_csrf = http_build_query(['_csrf' => $_COOKIE['_csrf']]);
        $token = http_build_query([
            'out_f_name'=>$vendorinfo->l_name,'out_l_name'=>$vendorinfo->f_name,
            'out_m_name'=>$vendorinfo->middlename,'out_street'=>$vendorinfo->adress,'out_zip'=>$vendorinfo->zip,
            'out_city'=>$vendorinfo->city,'out_state'=>$vendorinfo->state,'out_country'=>$vendorinfo->country,
            'f_name'=>$orderdb->d_l_name,'l_name'=>$orderdb->d_f_name,'m_name'=>$orderdb->d_m_name,'street' =>$orderdb->d_street,
            'zip'=>$orderdb->d_zip,'city'=>$orderdb->d_city,'state'=>$orderdb->d_state,'country'=>$orderdb->d_country,
            'order_total'=>$orderdb->order_total, 'delivery_type' =>$orderdb->delivery_time.' '.$orderdb->payment_params
            .' '.$orderdb->payment_method_id.' '.$orderdb->delivery_times_id.' '.$orderdb->shipping_method_id,
            'key_tranzaction'=>$plaginParams->mysecretkey,'_csrf'=>_csrf,'url'=>$_SERVER["SERVER_NAME"]]);
        curl_setopt($ch, CURLOPT_URL,'https://postalblank.ru/tranzaction/input.html');
        curl_setopt($ch, CURLOPT_POST,1);
        curl_setopt($ch, CURLOPT_COOKIE,$_csrf);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$token);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        $output = curl_exec($ch);
        $name_pdf = md5(uniqid(rand(0, 100))).".pdf";
        $file_puth = JPATH_SITE."/components/com_jshopping/files/pdf_orders/blank_".$name_pdf;
        file_put_contents($file_puth, $output);
        curl_close($ch);
        header("Location: "."/components/com_jshopping/files/pdf_orders/blank_".$name_pdf);
    }
}