<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.plugin.plugin');

class plgSystemJshoppPostalBlank extends JPlugin
{
    public function onAfterRender()
    {
        $content  = JResponse::getBody();
        $content = preg_replace(
            '~(<a href = "javascript:void window\.open.*pdf_orders/(\d+)_.*</a>)~smU',
            '$1<a href="javascript:void window.open(\'index.php?option=com_jshopping&controller=postalblank&task=display&order_id=$2\', \'win2\', \'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=yes,resizable=yes,width=800,height=600,directories=no,location=no\');">
                <img src="/images/Img_Russian_Post_20px.png"/>
            </a>',
            $content);
        JResponse::setBody( $content );
    }
}
