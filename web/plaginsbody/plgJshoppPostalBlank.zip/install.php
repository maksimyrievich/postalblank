<?php

class plgSystemJshoppPostalBlankInstallerScript
{
    public function __construct(JAdapterInstance $adapter){}
    public function preflight($route, JAdapterInstance $adapter){}
    public function postflight($route, JAdapterInstance $adapter){
        unlink(JPATH_SITE . '/plugins/system/JshoppPostalBlank/postalblank.php');
        unlink(JPATH_SITE . '/plugins/system/JshoppPostalBlank/Img_Russian_Post_20px.png');}
    public function install(JAdapterInstance $adapter){
        copy(__DIR__ . '/postalblank.php', JPATH_ADMINISTRATOR . '/components/com_jshopping/controllers/postalblank.php');
        copy(__DIR__ . '/Img_Russian_Post_20px.png', JPATH_SITE . '/images/Img_Russian_Post_20px.png');}
    public function update(JAdapterInstance $adapter){
        copy(__DIR__ . '/postalblank.php', JPATH_ADMINISTRATOR . '/components/com_jshopping/controllers/postalblank.php');
        copy(__DIR__ . '/Img_Russian_Post_20px.png', JPATH_SITE . '/images/Img_Russian_Post_20px.png');}
    public function uninstall(JAdapterInstance $adapter){
        unlink(JPATH_ADMINISTRATOR . '/components/com_jshopping/controllers/postalblank.php');
        unlink(JPATH_SITE . '/images/Img_Russian_Post_20px.png');}
}